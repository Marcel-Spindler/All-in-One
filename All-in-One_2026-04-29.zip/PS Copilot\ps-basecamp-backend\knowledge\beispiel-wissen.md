# Beispiel-Wissensdatei

Dies ist eine Beispiel-Markdown-Datei im `knowledge/`-Ordner.

## So funktioniert's
- Lege beliebige `.md`-Dateien in diesen Ordner
- Die PS-KI liest sie automatisch beim Start und bei jeder Anfrage
- Du kannst Prozesse, Checklisten, SOPs, Anleitungen etc. hinterlegen

## Beispiel: Waagen-Reset Checkliste
1. Tracking-Daten exportieren
2. Reset am Scales-Tool durchführen
3. Neue Woche im System anlegen
4. Waagen kalibrieren und Testlauf starten
