# DIE FIRMA – HelloFresh & FACTOR_

## Inhaltsverzeichnis
* SKUs
* FCMS
* JUPITER
* PRESSEBOXEN
* T4
* TAGESWECHSEL
* SKUCALL
* WOCHENWECHSEL
* SCALESERVER
* FACTOR_
* WAAGE
* GRAFANA
* NEUE_MA
* GERÄTEAUSGABE
* 100_PROZENT_CHECK
* DAS_BÜRO
* FUNKGERÄTE
* PRODUKTIONS_RUNDGANG
* NEAR_MISSES
* NEUE_MA
* USER_PASSWORT
* URLAUBSPLANUNG
* TAGESABSCHLUSS
* ALLE PASSWÖRTER

---

## Tagesablauf im Bereich: Problem Solving – Basecamp

### Tagesbeginn (Früh- und Spätschicht)
* Übergabeprotokoll durchlesen, Informationen an MA rausgeben, Einteilung des Teams (Wochen basiert): [Tabelle zur Einteilung](https://docs.google.com/spreadsheets/d/1RQQ9AOqDOwf_euJ83NU2kNSkFFlcFoxAaawYOpv3zK0/edit?gid=496378075#gid=496378075)
* Anschauen der SKU-Liste und der Verkürzten MHD's (MHD-entscheid):
    * SKU: [Link zur SKU-Liste](https://docs.google.com/spreadsheets/d/13D0aUpchbF9sIDKwS8Xr-oWESqQ5Wi2VP72h2iHJldo/edit?gid=48940979#gid=48940979)
    * Verkür. MHD's: [Link zu verkürzten MHDs](https://docs.google.com/spreadsheets/d/13D0aUpchbF9sIDKwS8Xr-oWESqQ5Wi2VP72h2iHJldo/edit?gid=1239129582#gid=1239129582)
* Falls Changes über eine längere Zeit aktiv sind, überprüfen wir regelmäßig die Stocks, um sicherzugehen, ob und wann das Produkt wieder verfügbar ist.

### Stock-Check mit FCMS bei SKU-Changes
* Link: [FCMS Tool](http://192.168.112.11/cgi-bin/web_om_hellofresh.exe?Language=1&scr=WEB_PageEnterSecurity&rec=-1&reframe=)
* Die Passwörter sind zu finden unter: [Passwort-Dokument](https://docs.google.com/spreadsheets/d/16o-CD2Rx2mSOf5nKSWozMenuxZkU8Fj4TpoDoy4WHJg/edit?pli=1&gid=1394895754#gid=1394895754)

### Jupiter
* Falls ein SKU-Change erstellt werden muss, haben wir "Jupiter" als Tool zu unserer Verwendung und eine SKU-Sub List welche alle Artikel enthält + alle freigegebenen Ersatzartikel enthält.
* SKU-Sub List: [Link zur Liste](https://docs.google.com/spreadsheets/d/1IuOiowJU52yqv1zf48aoPgwqZmkqNlCisXftFDAc0B8/edit?pli=1&gid=1465239925#gid=1465239925)
* Jupiter: [Jupiter Live](https://jupiter.live-k8s.hellofresh.io/)
* Jupiter enthält die komplette Datenbank aller Artikel in Hause HelloFresh DACH und kann für DE, AT und CH verwendet werden.
* Bei Erstellung eines Changes ist darauf zu achten, dass das Feld Country auf DEAT steht und als DC Verden ausgewählt ist.
* Ebenso muss die richtige HelloFresh Week ausgewählt sein, um nicht in einer Falschen Woche einen Change zu erstellen.
* Nach Erstellung eines Changes hat eine Meldung im Slack-Kanal `#verden-shortage-urgent` zu erfolgen.
* Auch bei Anfragen ist dieser zu benutzen.
* Eine Liste der Kontakte, die für die zuständigen Bereiche (PTN, PRO, PCK, etc.) verantwortlich sind finden wir hier: [Kontaktliste](https://docs.google.com/spreadsheets/d/1xMs3adTigyJ64wMWAUqzvJSaF2tIVqlhkwRT5xjCMlY/edit?pli=1&gid=663633134#gid=663633134)

---

## Die Presseboxen
* Presseboxen werden morgens überprüft und ggf. ausgedruckt, falls nicht schon von der Vorschicht vorbereitet.
* Gefunden werden diese im Ordner des jeweiligen Jahres.
* Presseboxen: [Drive-Ordner](https://drive.google.com/drive/folders/1_Jse4Mo1xOkQ_UTj1qbVqLm3CJ0yJ-Qu)
* Diese Boxen werden am Vortag vorbereitet, und am Versandtag vollständig geprüft und gepackt.
* **Diese Boxen dürfen keinesfalls über die ASL Produziert oder Versand werden!**
* Ebenso müssen MA in diesem Bereich anagelernt und vollständig bis zu einer vollständigen Eigenkompetenz unterstützt werden.

---

## Die Frühschicht
* In der Frühschicht gibt es einige Besonderheiten die Beachtet werden müssen.
* Das Tier 4, umgangssprachlich T4 genannt, wird für den Problem Solving eigenständig vorbereitet und in einem Meeting vorgetragen.
* Dieses Meeting findet immer um 09:30 Uhr statt und ist von hoher Wichtigkeit, da dort über diverse Themen wie Produktion, HR, Customer Care oder andere Abteilungen berichtet wird, welche immer mit dem Problem Solving zusammenarbeiten.
* Das T4 Board ist hier zu finden: [T4 Board](https://docs.google.com/spreadsheets/d/1XAQdjkaruClRCbzLkmuAdiwHKJfrQNl6WLxxvT00HS8/edit?gid=2006661885#gid=2006661885)
* Die Daten werden in der Docs Datei Tier KPIs eingetragen und berechnet.
* Diese ist hier zu finden: [Tier KPIs](https://docs.google.com/spreadsheets/d/1bY1YJuZUq6wB1sIFix7YbbSXO9XuydlECc1i_a-Aqps/edit?gid=282582412#gid=282582412)

### Datenabfrage & Eintragung
* Die Daten die Benötigt werden um dieses zu füllen, finden wir in Databricks unter den Querry´s:
    * Assembly QC DE 2.0: [Query Link](https://hf-query-engine.cloud.databricks.com/editor/queries/3538126942072784?o=1352089065939666)
    * Diese werden in Assembly Rohdaten mit Strg+Umschalt+V (Nur Werte) eingetragen.
    * Vor dem Eintragen kann man alle Daten löschen, indem man 2x Strg+A dann Entf drückt.
    * Kitting QC Verden 2.0: [Query Link](https://hf-query-engine.cloud.databricks.com/editor/queries/3538126942072785?o=1352089065939666)
    * Bei den Kitting Roh Daten ist dies ebenfalls so zu machen.
* Ebenso werden Daten aus dem sogenannten ''Schichtreport'' benötigt.
* Diesen finden wir hier: [Schichtreport Drive](https://drive.google.com/drive/search?q=schichtreport)
* Die Berechnung findet man unter der Karte PS-Kopiervorlage in dem Tier KPIs Docs.
* Falls der Schichtreport am Donnerstag leer sein sollte (wegen des Wochenwechsels) kann man die zahlen über den Link finden, indem man nach der Woche und dem Jahr sucht und auf das [Copy] achtet.
* Falls die Berechnung für Donnerstag, Freitag oder Sonntag ist, muss in der Berechnung bei "Spät nicht stattgefunden" ein Haken gesetzt werden, damit diese nicht mitberechnet wird.
* Nach Abschluss der Berechnung müssen die Daten aus A2+A3 bis P2+P3 kopiert werden und dann im KPI_Overview in der Problemsolving spalte im entsprechenden Tag (Immer der gestrige Tag ; Nur Sonntags vom Freitag) mit Nur Werte eingefügt werden.

---

## Der SKU-Call
* Der SKU-Call ist ein Google Meets Termin der immer Mittwochs um 10:00 Uhr und Donnerstags um 10:45 Uhr stattfindet.
* An diesem Termin ist es verpflichtend Teilzunehmen, um alle Informationen für die kommenden Wochen zu Erfragen.
* Falls von uns ein SKU-Change erstellt worden ist, müssen wir diesen dort einmal besprechen, damit wir wissen, ob vielleicht eine Lieferung extra geordert wird oder wir mit dem Ersatzartikel sogar leerlaufen etc.

---

## Der Tageswechsel
* Der Tageswechsel erfolgt in der laufenden Produktion, d.h. z.B. im Produktionstag Dienstag wird in der Spätschicht auf den Produktionstag Mittwoch gewechselt.
* Um einen Reibungslosen Übergang zu schaffen, erstellen wir ca. 1500 Boxen vor Wechsel des Produktionstages eine neue Tracking und Reset Datei, welche auf die Waagen Server aufgespielt wird.
* Diese werden einmal pro Tag über das Scales-Tool erstellt.

### Wiegetabelle und Databricks/Lassy
* Ebenso müssen wir auf die Wiegetabelle achten, dass das Sheet komplett ausgefüllt und gepflegt ist.
* Bei Anomalien (Gewichte mit starken Schwankungen, Gewichte nicht eingetragen) müssen wir die MA nochmals auf die Tabelle hinweisen und diese vervollständigen lassen.
* Die Wiege-Tabelle finden wir hier: [Wiege-Tabelle Link](https://docs.google.com/spreadsheets/d/1u2WjPiGDBiIgia43jIm5mvfw8YUlK_O8nGDHjGRSIQ0/edit?pli=1&gid=270088082#gid=270088082)
* Diese Tabelle muss sich jeden Tag angeschaut werden, damit wir mögliche Differenzen in den Gewichten schnellstmöglich erkennen, sodass wir ggf. eine Berechnung mit den Durchschnittsgewichten starten können.
* Das Scales Tool finden wir hier: [Scales Tool](https://docs.google.com/spreadsheets/d/1hYjvxAgeGfeVbjbkYYERu0Zsnc1JAY9Q3JXhsykLmP8/edit?gid=0#gid=0)
* Um die erforderlichen Daten zu erhalten müssen wir eine PDL-Datei aus Databricks ziehen und eine Picklist aus Lassy unter dem Reiter Fulfilment; Production Planning; Recipe Production Planning.
* Bei Lassy müssen wir, wie überall, auf die KW und das Jahr achten. Week XX – 2025 ; 2026 ; 2027 etc.
* Lassy: [Lassy Tool](https://operations.hellofresh.com/production-planning/warehouses-RPD/DE-VE/weeks/ce2229ea-688e-4472-a22e-2d38bcfdcb72?tab=ingredients&search=)
* Die Querry finden wir hier: [Query Link](https://hf-query-engine.cloud.databricks.com/sql/editor/ca61ba74-3ad1-473f-b4cb-abeb4c31c982?o=1352089065939666)
* Bei dieser Querry ist es wichtig, die hellofresh_week mit der derzeitigen Woche zu ziehen. D.h. in KW45 muss 2025-W45 gezogen werden.
* Wenn die Raw Results da sind, **MÜSSEN** diese als **CSV heruntergeladen und in den PDL Ordner gepackt werden**.
* Diesen finden wir hier: [PDL Ordner](https://drive.google.com/drive/folders/1-wQ3Gy2j5YkTilgRqIBhvyvmrP3hMWve)
* In der Jeweilige Woche und dem jeweiligen Cut-Off (CO 1- CO6) werden die CSV abgespeichert und müssen anschließend nochmal in CO1, CO2, CO3, CO4, CO5 oder CO6 umbenannt werden.

### Sampling & Scales Tool
* Wichtig ist, das auch die Wiegung vollständig abgeschlossen wurde und alle Gewichte korrekt in der Tabelle enthalten sind.
* Die Wiegeliste finden wir hier: [Wiegeliste Link](https://docs.google.com/spreadsheets/d/1u2WjPiGDBiIgia43jIm5mvfw8YUlK_O8nGDHjGRSIQ0/edit?pli=1&gid=270088082#gid=270088082)
* Ebenso müssen wir auf das Sampling achten, welches sich jede Woche ändern kann.
* Um hier auf der Sicheren Seite zu sein, haben wir eine Tabelle Namens: DACH Marketing Planning Overview.
* In dieser Tabelle sind alle Samplings des Jahres mit dem jeweiligen Samplecode und Gewicht eingetragen.
* Aus dieser Liste können wir uns dann aus der entsprechenden KW den Samplecode und das Gewicht rausnehmen und im Scales Tool unter C34 und D34 einpflegen.
* Eine Doppel PDL-Berechnung kann gemacht werden, ist aber nicht von Nöten.
* Nachdem wir hier alles eingetragen haben und auf Los geklickt haben, können wir nach der Berechnung auf den Link in G5 (Letzter Output) gehen um dort unsere Tracking und Reset zu erhalten.
* Diese wird einfach heruntergeladen und anschließend auf den Waagen Server aufgespielt.
* Hierzu haben wir einen Ordner Namens daily_csv. In diesem werden erst die Tracking und dann die Reset hineinkopiert.
* Da diese nicht Zeitgleich in dem Ordner verweilen dürfen, müssen wir abwarten, bis die Tracking durch ist und aus dem Ordner verschwindet.
* Erst danach dürfen wir mit der Reset folgen.

### Server Bedienung
* Um uns alles besser zu veranschaulichen, haben wir die Remotedesktopverbindung um uns zu helfen.
* Die Anmeldeeinstellungen sind:
    * Computer: `10.112.210.249`
    * Benutzername: `HFVD0066\ScaleServer`
* Das Zulassen des Speicherns der Anmeldeinformationen sollte nicht angewählt werden, da das Passwort zum benutzen des PCs noch eingegeben werden muss, und dies immer händisch vonstattengehen soll.
* Das Passwort zur Benutzung ist: `HelloFresh2024!`
* Nachdem wir Zugriff auf den PC haben, dürfen wir auf diesen:
    * In garkeinem Falle ungefragt den T-Wedge (MT-DBPump) schließen
    * Nicht im Internet surfen
    * **NIEMALS DEN PC VOLLSTÄNDIG HERUNTERFAHREN**
* Eine Abmeldung folgt nur über das X im oberen Bildschirmbereich. Niemals über den Powerbutton auf dem Server.

---

## Der Wochenwechsel
* Der Wochenwechsel ist im groben sinne, wie der Tageswechsel. Die Daten der Waage werden jedoch komplett Entfernt und wir müssen einige Kleinigkeiten mehr beachten.

### Der Rackfile-Check und die Zutatenliste
* Der Rackfile-Check ist eine Kontrolle des Rackfiles, welches wir an der Linie benutzen.
* Theoretisch ist es die Essence die HelloFresh am leben lässt. Ohne Funktionierendes Rackfile, sind die ASL nutzlos.
* Der Rackfile-Check wird in Verbindung mit der Aktualisierung der Zutatenliste gemacht.
* Die Zutatenliste ist eine Liste über alle Positionen die in der Produktionswoche im Kitting und an der ASL eingesetzt werden.
* Diese Liste wird nach (vollständigem) Abschluss der KW in einem Sheet ersetzt und per AppScript auf zwei Tabellen gespiegelt.
* Die Zutatenliste finden wir unter: [Zutatenliste Link](https://docs.google.com/spreadsheets/d/1oEBzPVOhwBYBgmw99fOWLQpgSst_reiva2fjbyBo2YA/edit?pli=1&gid=402941272#gid=402941272)
* Im groben Sinne ist die Zutatenliste nur die Pickliste in andrer, bzw. finaler Form.
* Auf der Registerkarte "Eingabe" wird die Picklist per "Nur Werte" eingefügt. Danach drücken wir erst den Button:
    * Picklist & Single Picks
    * dann: Rackfile-Check
    * und anschließend: Zutaten aktualisieren.
* Wenn dies getan wurde, ist die Zutatenliste und der Rackfile-Check vollständig vorbereitet.
* Wir können nun unter der Registerkarte "Rackfile-Check" alle Positionen an der ASL kontrollieren.
* Dies wird in Verbindung mit einem Supervisor aus der Produktion an einer ASL getan.
* Wenn wir hier Anomalien finden, werden diese in dem Drop-Down Menü angewählt und mit "n.i.O." in Rot hinterlegt und markiert.
* Wenn alles passt und keine Anomalien auftreten, wird im Drop-Down Menü "i.O." angewählt und das Feld wird grün hinterlegt markiert.
* Nach Beendigung des Rackfile-Checks prüfen wir einmal alle Positionen auf i.O. oder n.i.O. und geben ggf. n.i.O. positionen an die Produktions Planung weiter, damit diese sich das Problem im Deep-Dive ansehen können.

### Die Waage
* Bei einem Wochenwechsel muss der Server einmal Deleted und neu gestartet werden.
* Dies ist unter Aufsicht des Area Managers Problem Solving oder dessen Vertreter zu tun, da ein Missinput fatale Folgen haben könnte.
* Nach einem Delete und Neustart haben alle Waagen an den ASL-Linien einen Neustart durchzuführen, da die Verbindung zu dem Server getrennt war, und erst nach Neustart der Waage wieder hergestellt wird.
* Nachdem alles neu gestartet worden ist, können wir die Daten für die Neue Woche aufspielen.
* Wichtig ist, das wir erst die Tracking, dann die Reset aufspielen, da wir sonst den T-Wedge überlasten und dieser Fehler in der Berechnung der Box-IDs macht.
* Nach diesem Step können die Waagen wieder 100% benutzt werden.

---

## Factor_
* Die Produktion des neuen Unternehmens Factor_, folgend mit "F_" gekürzt, erfolgt nur am Freitag und Sonntag.
* Hier ist es wichtig, direkt am Freitag in der Frühschicht eine vollständige Wiegung durchzuführen, um sicherzugehen, dass das Scale-Tool mit den korrekten Gewichten berechnet.
* Die Wiegetabelle von F_ ist hier zu finden: [Wiegetabelle F_](https://docs.google.com/spreadsheets/d/1O7yp2iRh0VVgimQFWi5TbyH6Q5RfoSM4kwNrdD48gms/edit?gid=1819534671#gid=1819534671)

### F_ Berechnung und Auswertung
* Zum starten der Berechnung wird die Picklist, die PDL und die Gewichte benötigt.
* Die Picklist findet man im Scales-Tool: [Scales-Tool Link](https://docs.google.com/spreadsheets/d/1sMIrsPPeDw4NdUJh7NMuQ2ljYMhEKGh7aL9MIJ5naFo/edit?gid=0#gid=0)
* Unter dem Reiter "Picklist": [Picklist Link](https://docs.google.com/spreadsheets/d/1sMIrsPPeDw4NdUJh7NMuQ2ljYMhEKGh7aL9MIJ5naFo/edit?gid=2073175814#gid=2073175814)
* Ebenso wichtig ist die "Picklist_Marcel": [Picklist_Marcel Link](https://docs.google.com/spreadsheets/d/1sMIrsPPeDw4NdUJh7NMuQ2ljYMhEKGh7aL9MIJ5naFo/edit?gid=17450656#gid=17450656)
* Für die PDL benötigen die eine eigene Querry namens "TK&TV&TZ Coolnull". Diese Querry ist eine andere als die für HelloFresh.
* Zu finden ist diese hier: [Query Link](https://hf-query-engine.cloud.databricks.com/sql/editor/281aeece-0012-4b23-b96f-fa1994d89088?o=1352089065939666)
* Die Picklisten können einfach über den "Export als Excel" Button in die jeweiligen Ordner gedownloadet werden, das Speichern passiert komplett automatisch.
* Ansonsten sind die Steps für die Berechnung dieselben wie bei dem HelloFresh Scales-Tool.
* Nach Abschlusses der Produktion von F_ müssen wir eine Auswertung aller Produzierten Boxen, dessen Fehler und Swaps der Meals (falls wir welche haten) Erfassen und auswerten.
* Dafür haben wir verschiedene Querys und Tools zu unserer Verwendung.
* Ein Tool, welches wir benötigen, ist das `incident_tool_gui.py` und die Factor EU – Dynamic Swaps.
* Das ITG hilft uns bei dem Erfassen der verschiedenen Ersatzartikel.
* Die Dynamic Swaps sind eine Liste, welche uns zeigen, mit welchen Proteinen wir welche Meals ersetzen.
* Im Grafana können wir einen Data Extract ziehen welchen wir für die Erfassung der Meal-Swaps benötigen.
* Die Links zu den Tools sind hier zu finden:
    * ITG: [Drive Link](https://drive.google.com/drive/folders/1rVcUdjraKiWy6JR5_kE7PIaO50dJkgRK)
    * Factor EU – Dynamic Swaps: [Spreadsheet](https://docs.google.com/spreadsheets/d/16bk1aWdkynIDgJtBLcP-JD-CTXHt5pRb7UnZa4_Bj84/edit?gid=1885338613#gid=1885338613)
    * Grafana Data Extract: [Grafana Dashboard](https://dash.hellofresh.com/d/xSdvpqrWz/dc2-data-extract?orgId=1&from=now-24h&to=now&timezone=browser&var-Country=DE&var-City=Verden&var-hf_week=2025-W45&var-select_hf_week=Current%20Week&var-select_production_day=Monday&refresh=1d)
* Bei dem Data Extract ist wichtig zu wissen, dass wir hier immer nach einem time-filter gehen.
* Diesen können wir über den Reiter im oberen rechten Bereich einstellen.
* Wir wählen hier immer von Freitag – Sonntag aus, um alle Boxen der Produktionstage zu erfassen und diese im ITG korrekt zu erfassen.
* Bevor wir das ITG öffnen, müssen wir dies erst einmal auf unseren Desktop per Verknüpfung senden, und das `Incident_Tool_User_Guide_Full.docx` öffnen.
* In der docx ist eine detaillierte Anleitung der Steps, das Programm zum Laufen zu bekommen.
* Da die Datei nicht direkt aus dem Drive geöffnet werden soll, müssen wir hier erst eine Verknüpfung in "Meine Ablage" erstellen, welche wir dann auf unseren Desktop verknüpfen senden damit wir das Programm immer Aktuell und geupdated werden kann.
* Nachdem der Prozess in der ITG beendet worden ist, müssen wir die Ergebnisse in einem Google Docs Format in dem sogenannten "Weekly Bug Report" einfügen.
* Diesen finden wir hier: [Bug Report](https://docs.google.com/spreadsheets/d/1oowAygc7_vf27BDoqnfpjg3rxuHqmQ5cvHOtz5KwU9s/edit?gid=1105010246#gid=1105010246)
* Auf der ersten Seite, der Guideline, finden wir eine detaillierte Anleitung des Prozesses, mit einem Databricks Link, für die Querry "Assembly QC Factor".

---

## Vertretung der QA
* Es kann vorkommen, das wir als PS die QA Vertreten müssen.
* Hier werden wir jedoch nur die "Tafelliste" beantworten. Diese kommt jeden Tag, morgens um punkt 06:00 Uhr.
* Hier gleichen wir einmal unsere Zutatenliste und die Tafelliste ab, ggf. mit dem FCMS, damit wir 100% sichergehen können, dass das Produkt entweder:
    * Nicht in der derzeitigen KW benötigt wird.
    * Nicht mehr vom MHD her eingesetzt werden darf.

---

## Grafana
* Grafana ist ein Tool zur Einsicht des Produktionsstatus, Speeds an den ASL und dem Kitting und der Daten Extraktion.
* In Grafana haben wir diverse Optionen, Daten einzusehen wie zum Beispiel, Abfahrtszeiten der Prio´s oder die jeweiligen Courier.
* Ebenso können wir jeden Tag den Boxcount zu jedem Produktionstag, welche Linien gefahren, welche Personengrößen produziert und welcher MA an welcher Linie Boxen Kontrolliert hat, einsehen.
* Grafana finden wir hier: [Grafana Dashboard](https://dash.hellofresh.com/)
* Die Anmeldedaten sind wie folgt:
    * Email: `verden-grafana@hellofresh.de`
    * Passwort: `Dashy123`
* Um auf die Homepage zu kommen, müssen wir oben links auf die "Sonne" tippen.
* Von dort aus können wir alle wichtigen Daten einsehen um z.B. die Daten für den Tageswechsel vorzubereiten oder entsprechende Maßnahmen zu ergreifen, falls wir hier mit extremen Performance Problemen kämpfen.

---

## Spätschicht
* In der Spätschicht haben wir, bis auf einige Ausnahmen, die selben Aufgaben wie in der Frühschicht.
* In der Spätschicht wird z.B. kein T4 abgehalten, keine Wochenwechsel durchgeführt oder Presseboxen gepackt (nur vorbereitet[auf Anfrage]).
* Die Grundprinzipien sind gleich und können in der Früh- als auch der Spätschicht angewendet werden.
* Wichtig ist, dass die Aufgaben, in der Früh- sowie der Spätschicht, klar strukturiert durchgeführt werden, um sich selbst oder andere zu verwirren.

---

## Neue Mitarbeiter (MA)
* Wenn wir Neue MA erhalten, müssen wir mit diesen einen Rundgang durch die gesamte Produktion durchführen.
* In diesem Rundgang erklären und erzählen wir diesen, den Tagesablauf, welche Sachen und Regeln zu beachten sind und wie ihr Arbeitsplatz und die Aufgaben aussehen.
* Währenddessen, führen wir mit diesen MA ein Kennenlerngespräch um mehr über ihren Background herauszufinden und ihre Kompetenzen zu sehen.
* Wenn das Gespräch mit dem Rundgang beendet worden ist, geben wir die neuen MA an einen erfahrenen MA ab, damit dieser dem neuen MA in einem Hands-On-Hands Training über eine Woche alles zeigen und erklären kann.
* Anschließend gibt es eine Beobachtungszeit des MA bei der Arbeit, die durch die erfahrenen MA, den Supervisor oder Area Manager durchgeführt werden.
* In dieser Zeit sprechen wir von dem sogenannten "Welpenschutz".
* Der neue MA soll nicht länger als zwei Wochen beaufsichtigt werden und nach etwa ein bis zwei Tagen autonom Arbeiten können.
* Falls Schwierigkeiten bestehen z.B. durch Sprachbarrieren oder Einschränkungen im Körperlichen oder Geistigen Sinne, können und müssen diese zeiten verlängert werden.
* Der erfahrene MA, welcher die neuen MA anlernt ist immer zu befragen, wie:
    * Das Arbeitsverhalten der Person ist
    * Ob Sprachbarrieren eine Herausforderung darstellen
    * Wie der MA sich in einem Fehlerfall verhält (Aufgeregt, Gelassen, Überfordert)
    * Ob der MA Lust an der Arbeit zeigt, viele Fragen zu Artikeln o.Ä. stellt.
* Wenn der erfahrene MA sich mit der Person zufrieden gibt und diesen als "Alleinläufer" bezeichnet (MA kann alleine laufen) ist die "Welpenschutz"-Zeit vorbei und der MA ist ein Vollmitglied des PS-Teams.

---

## Die Geräteausgabe
* Die Geräteausgabe erfolgt zu den Zeiten:
    * 05:45 – 6:15
    * 10:45 – 11:15
    * 11:45 – 12:15
    * 14:45 – 15:45
    * 20:00 – 20:40
* In diesen zeiten werden Geräte an allmögliche MA ausgegeben, welche z.B. ein Funkgerät, Tablet oder E-Hubwagen-Schlüssel benötigen.
* In dieser Zeit müssen zwei Mitarbeiter abgestellt werden damit die Geräteausgabe vollständig abgedeckt ist und es nicht zu einem Rückstau mit der Ausgabe kommt.
* Das Programm, welches wir hier verwenden, ist Untouch.
* Der Link ist: [Untouch Tool](https://hellofresh.untouch.de/)
* Die Logindaten sind von dem Supervisor oder dem Area Manager zu erhalten.
* Falls die Handys, der PC oder der Server im allgemeinen mal nicht erreichbar oder funktionsfähig ist, warten wir erstmal einen Tag ab, da wir hier erst von einem Untouch-Problem ausgehen.
* Wenn der Fehler nach einem Tag nicht behoben ist, kontaktieren hier den Untouch-Kundendienst. Unser Ansprechpartner hier ist:
    * Dr. Thomas Müller erreichbar unter der Tel.-Nr.: +49 2232 501550
* Untouch wird durch die Coeln Concept GmbH vertrieben und gemanaged, also nicht wundern, falls die Nummer die Coeln Concept GmbH anzeigt. :)

---

## 100% Check
* Bei dem 100% Check handelt es sich um eine Mealkit, folgend "MK", Kontrolle, welche uns dabei hilft im Kitting mehr auf Pickmuster und Fehler zu achten.
* Der 100% Check erfolgt im Kitting und dem Dolly-Bahnhof, folgend "DB" genannt, und ist essenziell für unsere laufende Produktion.
* Der 100% Check wird von MA übernommen, welche für das Kitting eingeteilt werden und diese erfüllen ihre Tätigkeit die ganze Produktionswoche lang.

---

## Produktionsrundgänge
* Der Produktionsrundgang ist eine Tägliche Aufgabe, wo die Supervisor und/oder Area Manager dran teilnehmen, damit eventuelle Gefahren sofort gemeldet werden können, um Unfälle zu vermeiden. Den Link zur Umfrage gibt es hier: [Produktionsrundgang Formular](https://docs.google.com/forms/d/e/1FAIpQLSfMyMP8KLLE7AXS_yUBl12m2UWQMOWjZkzffRrU7PDEuxr6gg/viewform?pli=1&pli=1&fbzx=-3148792522356238747)

### Near Misses
* Zusätzlich gibt es eine Google Docs Form, wo wir Near Misses eintragen können.
* Near Misses sind im allgemeinen Beinaheunfälle.
* Wenn uns ein Near Miss auffällt, müssen wir diesen Melden.
* Ein "kaputter Tisch" ist kein Near Miss, da dies ein Reparaturauftrag ist.
* Ebenso sind Near Misses nur dann Near Misses wenn diese sofort hätten verhindert werden können.
* Hier ein Beispiel eines Near Misses: [Abbildung im Originaldokument]
* Ein Near Miss ist also nichts anderes als eine Sache die hätte verhindert werden können, wenn man Sicher gehandelt hätte.
* Solche Near Misses sind sofort zu Melden und mindestens Drei stück müssen pro Tag eingetragen werden.
* Der Link zu dem Near Miss Formular ist hier zu finden: [Near Miss Formular](https://docs.google.com/forms/d/e/1FAIpQLSeBDYIo7SHUc7Yi73kI37uL3uv2SQwMtVJLpSW6yWY-YNAyAg/viewform)

---

## User Passwörter
* Die User Passwörter sind die sogenannten "Anmelde-ID´s". Mit diesen können sich die MA in unseren QC-Tools einloggen und diese verwenden.
* Jeder MA hat seine eigenes User Passwort, welches Static ist und sich nicht ändert.
* Anhand des User Passwortes kann man jeden MA der PS-Abteilung einzeln erkennen und abgleichen, ob:
    * Dieser an jenem Tag in Hause war
    * Wie die Performance des MA an besagtem Ta hatte
    * Mit welchem Speed der MA kontrolliert hat.
* Wenn wir einen neuen MA bekommen, muss dieser mit einem User Passwort versehen werden, den Er/Sie/Es dann jeden Tag während der Arbeit nutzen muss.
* Wenn ein MA das Unternehmen verlässt, kann der Name des ehemaligen MA aus der Liste ausgetragen werden.
* Bei jedem MA der das Team wechselt, muss nur das Team in dem Sheet geändert werden.
* Den Link zum User Passwort Sheet findet ihr hier: [User Passwort Liste](https://docs.google.com/spreadsheets/d/1rXZbe9WcN6dh2fr7sYO-jrL1YBxg1jq6vh7SJA0RH10/edit?gid=0#gid=0)

---

## Urlaubsplanung in den Teams
* Wenn wir die Urlaubsplanung vornehmen, müssen wir immer darauf achten, dass die Planung:
    * Am Anfang des Jahres erfolgt.
    * Höchstens drei Urlaubstage überbleiben.
    * Nur ein MA zur Zeit Urlaub machen darf.
* Wenn wir den Urlaub der MA genehmigen, gehen wir nach dem "First come, First serve" Prinzip.
* Jedoch müssen wir hier die MA mit (Kleinen-)Kindern beachten und an bestimmten Zeiten bevorzugen.
* Hierzu zählen die Zeiten von:
    * Weihnachten
    * Neujahr
    * Sommerferien
    * Winterferien
    * Herbstferien
    * Osterferien
* Wenn wir keine MA haben, welche (trotz Kindern) an diesen zeiten Urlaub haben möchten haben, können wir diese Zeiten an andere MA abgeben.
* Ein "Dauerurlaub" von z.B. 30 Tagen muss im Vorfeld zusammen mit dem Supervisor und dem Area Manager geklärt und begründet werden (Feiertage anderes Glaubens, Fastenzeit, Besuch der Familie im Ausland, etc.).
* Wenn an sich nicht gegen einen Antrag spricht, kann dieser problemlos genehmigt werden.
* Zum Eintragen des Urlaubes haben wir diese zwei Sheets:
    * Team 1: [Tabelle Team 1](https://docs.google.com/spreadsheets/d/1qZdhkpIDHHopUDdVN-36wrNgMhqTvgeHmoDckNYNiYg/edit?pli=1&gid=1699636455#gid=1699636455)
    * Team 2: [Tabelle Team 2](https://docs.google.com/spreadsheets/d/1lSapxqQTf9KzjMufVgg_kx30aPSRfGpLtBhy6TJ-Jvo/edit?gid=1532413416#gid=1532413416)
* Eine Zusammenfassung beider Teams finden wir hier: [Zusammenfassung Urlaubsplanung](https://docs.google.com/spreadsheets/d/1B_QrTQ4YayPv7vREEsYr4eYuLm1k-wX5SONgwKWug98/edit?gid=1904172521#gid=1904172521)

---

## Das Büro
* Das Büro ist der Ort wo sich Supervisor, Area Manager und MA einfinden, wenn es z.B. um Personalgespräche, Schichtübergaben, Allg. Fragen oder anderes geht.
* Das Büro ist nebens dem im Logistikbüro angesiedelt und Teilt sich einen aus fünf Plätzen mi dem Supermarktteam.
* Das Büro ist ein Büro, hier gibt´s eigentlich nichts Besonderes zu sehen oder zu hören.
* Wenn die Reinigungskolonne das Büro betritt, ist es Ratsam, diese ihre Arbeit erledigen zu lassen.
* Wenn der Boden gewischt werden soll, verlassen alle das Büro und warten ca. 5-10 Minuten ab, bevor sie den Raum wieder betreten.
* Zum Schichtabschluss ist das Büro und die Arbeitsplätze:
    * Sauber
    * Ordentlich
    * Organisiert
    * Und mit ausgeschaltetem Licht
    * Zu verlassen.
* Wenn das Licht angeschaltet bleibt, ist es unnötige Mehrarbeit für die Security, welche dann in den Raum kommt, um dieses auszuschalten.

---

## Funkgeräte und Mobiltelefone
* Die Funkgeräte müssen immer auf einem akzeptablen Pegel eingestellt sein.
* Wenn es in der Produktion laut wird, haben wir hier das Funkgerät zwischen Lt. Stärke Sieben und Zehn eingestellt.
* Sobald ein Raum im allgemeinen oder das Büro Betreten wird, sind die Funkgeräte zwischen Lt. Stärke Eins und Drei eingestellt zu sein.
* Sobald der Raum verlassen wird, stellen wir dies wieder auf die Normale Einstellung zwischen Vier und Sechs ein.
* Mobiltelefone müssen immer auf "Laut" gestellt sein. Im Falle eines Meetings stellen wir dieses auf Lautlos oder Vibration.
* Sobald wir ein Meeting beendet haben, stellen wir dieses wieder auf "Laut".
* **Wichtig zu beachten:** Privatgeräte sind in der Produktion strengstens untersagt!
* Eine Nutzung ist nur dann erlaubt, wenn dies von dem Supervisor oder Area Manager dies freigibt.

---

## Tagesabschluss
* Der Tagesabschluss findet mit der Übergabe und dem Aufspielen der Waage mit frischen Daten statt.
* Wenn wir den Tag beenden, müssen wir alles Wichtige in der Übergabe erfassen und die Waagen Daten einmal neu (mit frischen Gewichten) aufspielen.
* Wenn dies erledigt ist, können wir den Tag abschließen und das Unternehmen verlassen.
* Irrtümer und Änderungen sind vorbehalten.
