export const firebaseConfig = {
  apiKey: "AIzaSyArq_NoE8IgsmrqRzLXHLwI1Fsj7yG_HPQ",
  authDomain: "hellofresh-de-problem-solve.firebaseapp.com",
  projectId: "hellofresh-de-problem-solve",
  storageBucket: "hellofresh-de-problem-solve.firebasestorage.app",
  messagingSenderId: "853119829386",
  appId: "1:853119829386:web:e581a856d33c0aab437473",
  measurementId: "G-XWWRYL6RSD"
};