# MPT – Manufacturing Planning Tool (Produktionsplanungs-Tool)
## Vollständige Referenz für Marcel | Übersetzt aus dem englischen Benutzerhandbuch (Dezember 2025)

---

## WICHTIGE LINKS

- **MPT (Produktionskalender):** https://operations.hellofresh.com/rte-manufacturing-planning/production-schedule
- **MPT Kalender-Schulungsvideo:** https://drive.google.com/file/d/1Cc7cWXckgJbeQ9918GMQRyWzLQjd91Q5/view?usp=drive_link
- **Slack-Support:** #rtem-planning-execution-tool-support

---

## WAS IST DAS MPT?

Das Manufacturing Planning Tool (MPT) ist das zentrale Planungstool für die Produktionsplanung bei HelloFresh. Es wurde komplett neu gestaltet und bringt eine radikale Erweiterung der Funktionen mit sich. Planer können jetzt gegen tägliche Mindestbedürfnisse (Min Needs) planen, um das Platier-Datum zu ermitteln, und dann von diesem Datum rückwärts zum Kochtermin arbeiten.

**MPT-Link:** https://operations.hellofresh.com/rte-manufacturing-planning/production-schedule

---

## 1. WAS HAT SICH GEÄNDERT – REZEPT-LEVEL-PLANUNG

### Rezept-Arbeitsaufträge (Recipe Work Orders)
- Repräsentieren **Platierläufe** – die Endmontage aller Rezeptkomponenten
- Jeder Rezept-Arbeitsauftrag gibt einen Ziel-Prozentsatz des wöchentlichen Bedarfs für diesen Platierlauf an
- Planer erstellen Rezept-Arbeitsaufträge 3 Wochen vor der Produktionswoche

### Sub-Rezept-Arbeitsaufträge (Sub-Recipe Work Orders)
- Repräsentieren alle Arbeiten bis zum Kochen des Sub-Rezepts
- Sub-Rezepte haben keine Laufnummern oder Zielprozentsätze mehr – das gehört jetzt zu den Rezept-Arbeitsaufträgen
- Sub-Rezept-Arbeitsaufträge werden automatisch generiert, wenn Rezept-Arbeitsaufträge erstellt werden

### Constraint Management (Planungsbeschränkungen)
MPT validiert aktiv 5 Kernbeschränkungen in Echtzeit:
1. **Min Needs (Mindestbedarf)** – Stellt sicher, dass tägliche Mindestbedarfe erfüllt werden
2. **Rezept-Bedarf** – Überprüft, ob Sub-Rezept-Mengen ausreichen für den Platierlauf
3. **Gerätekapazität** – Markiert überausgelastete Küchengeräte
4. **Haltbarkeit (Shelf Life)** – Bestätigt, dass Kochzeit bis Platierzeit innerhalb sicherer Grenzen liegt
5. **Frühester Platier-Tag** – Überprüft, ob Rezept-AAs nicht zu früh geplant sind

---

## 2. KALENDER-NAVIGATION

### Erste Schritte
1. **Distribution Center auswählen** – Das Lager, für das du planst
2. **Menu Week auswählen** – Die Menüwoche, die du planst

### Kalender-Layout
- **Kalender-Header:** 10-Tage-Produktionszeitraum (Samstag bis Montag), jeder Tag mit Schicht 1 und Schicht 2
- **Linkes Panel:** Rezept- und Sub-Rezept-Informationen mit aufklappbaren Details
- **Kalender-Grid:** Arbeitsaufträge als "Chips" in ihrem geplanten Datum/Schicht-Slot

### Linkes Panel – Informationen je Zeile
| Datenpunkt | Beschreibung |
|---|---|
| Rezept/Sub-Rezept-Name | Vollständiger Name aus MSKU |
| Rezept/Sub-Rezept-Code | Eindeutige Kennung (z.B. REC-002035-4-002) |
| Bedarf (Demand) | Wöchentliche Prognose mit Prozentsatz des geplanten Betrags |
| WIP und Mapped Quantities | Aktueller Lagerbestand aus dem WMS |
| Aufklapp-Kontrollen | Sub-Rezept-Zeilen ein-/ausblenden |
| Kochmethoden | Alle Geräte für ein Sub-Rezept |
| Co-Manufacturer-Pillen | Farbige Pillen für Co-Manufacturer: Artisan (A), Fresco (F), Brett Anthony (BA) |
| Transfer-Pille | Zeigt an, wenn Mahlzeiten ausgelagert werden |

---

## 3. CHIPS VERSTEHEN (VISUELLE ELEMENTE IM KALENDER)

### Min Needs Chips (Mindestbedarfs-Chips)
- Erscheinen eine Woche vor Produktionsbeginn
- **"Plan: X"** – Kumulative Summe aller geplanten Rezept-AAs bis zu diesem Tag
- **"Min: X"** – Täglicher Mindestbedarf als kumulative Summe
- **Rote Chips** = Planung reicht nicht aus für Mindestbedarf → Differenz = Min - Plan

### Rezept-Arbeitsauftrag-Chips
- Repräsentieren Platierläufe
- Zeigen AA-Nummer, Zielmenge, Sperrsymbol wenn gesperrt
- **Grau** = Geplant (ungesperrt/gesperrt)
- **Grün** = Aktiv/Abgeschlossen (in Ausführung)
- **Rot** = Constraint-Verletzung!
- **Orange** = Constraint-Warnung, nähert sich Grenze

### Sub-Rezept-Arbeitsauftrag-Chips
- Repräsentieren Kochvorgänge
- **Grau** = Geplant
- **Grün** = Kochvorgang abgeschlossen
- **Rot** = Constraint-Verletzung
- **Tortendiagramm-Icon** = WMS-Ausführungsphasen (Picking → Staged → Debox → Kitchen → Pre Blast → Post Blast → Holding Cooler)

### Blaue horizontale Linie im Kalender
- Markiert den frühesten Platiertag für ein Rezept
- Rezept-AAs auf ODER NACH dieser Linie planen!

---

## 4. VORLÄUFIGE PLANUNG (3 WOCHEN VORAUS)

### Rezept-Arbeitsauftrag erstellen
1. Rezept-Zeile im Kalender identifizieren
2. Zieldatum und Schicht identifizieren
3. Beim Hovern auf die Zelle → **"+ Add Plan"** klicken
4. Formular ausfüllen:
   - **Zielmenge:** Anzahl Portionen ODER Prozentwert des Wochenbedarfs (MPT rechnet automatisch um)
   - **Platier-Datum:** Bereits vorausgefüllt, editierbar
   - **Platier-Schicht:** Bereits vorausgefüllt, editierbar
   - **Erstellungsgrund:** Aus Dropdown wählen
   - **Kommentar:** Optional

### Sub-Rezept-Arbeitsaufträge auto-generieren
- **Checkbox "Sub-Rezept-AAs erstellen"** aktivieren beim Erstellen des Rezept-AA
- Sub-Rezepte werden automatisch in der Schicht VOR dem Rezept-AA eingeplant
- Alle Sub-Rezepte werden mit vorausgefüllten Werten angezeigt
- Einzelne Sub-Rezepte können vor dem Speichern angepasst oder entfernt werden

### Speicheroptionen
- **"Ungesperrt speichern" (Save as Unlocked):** Empfohlen! Erlaubt automatische Zielmengeanpassung bei Prognoseänderungen
- **"Speichern & Sperren" (Save & Lock):** Erstellt und sperrt sofort

---

## 5. CONSTRAINT AUFLÖSUNG (LAUFEND)

### Constraint-Typen & Schnellreparatur

| Constraint | Was wird geprüft | Schnelle Lösung |
|---|---|---|
| Min Needs | Tägliche Mindestmengen erreicht? | Rezept-AAs hinzufügen oder Zielmengen erhöhen |
| Rezept-Bedarf | Sub-Rezept-Menge reicht für Platierlauf? | Sub-Rezept-AAs hinzufügen oder Rezept-Ziele anpassen |
| Gerätekapazität | Küchengeräte nicht überlastet? | Arbeitsaufträge auf andere Schichten verteilen oder Cook-Method-Overrides nutzen |
| Haltbarkeit / Waste Risk | Kochzeit-bis-Platierung innerhalb Schwellenwert? | Kochtermin näher an Platierung verschieben |
| Frühester Platiertag | Rezept nicht zu früh geplant? | Rezept-AAs auf oder nach frühestem Platiertag verschieben |

### Warnungen finden und beheben
1. **Oranges Warnsymbol im Header** → Klicken für alle Verletzungen
2. **Orange markierte AA-Chips** → Klicken für spezifische Probleme
3. **Änderungen vornehmen** – Zielmengen, Timing oder neue AAs hinzufügen
4. **System re-validiert** automatisch nach dem Speichern

### Beispiele
- *"Mindestbedarf für 15. Juni nicht erfüllt, Differenz: 150 Einheiten"*
  → Roten Min-Needs-Chip klicken → Rezept-AA für diesen Tag hinzufügen oder bestehende Zielmengen erhöhen
- *"Gerätekapazität überschritten: Braiser über Kapazität am 15. Juni Schicht 1"*
  → Equipment-Drawer öffnen → AAs auf andere Schichten verschieben oder Cook-Method-Overrides in Sub-Rezept-Popovers nutzen

---

## 6. ENDPLANUNG (1–2 WOCHEN VORAUS)

### Prognose-Übergang (OSCAR → Min Needs)
**OSCAR-Prognose (ab 3 Wochen voraus)**
- Wird für die erste Planung mit wöchentlichen Gesamtprognosen verwendet
- Puffer-Logik:
  - < 10.000 Portionen: +100 Puffer
  - 10.000–20.000 Portionen: +150 Puffer
  - ≥ 20.000 Portionen: +1% Puffer

**Min Needs Übergang (1 Woche voraus)**
- Min Needs ersetzen OSCAR-Prognose
- Wochensumme = Summe der täglichen Min Needs (kein Puffer mehr)
- System synchronisiert automatisch Zielmengen für ungesperrte AAs
- Min Needs Chips erscheinen und zeigen tägliche Anforderungen

### Manuelle Sub-Rezept-Arbeitsaufträge erstellen
Nötig bei:
- Prognoseänderungen
- Ausführungsproblemen (Blast verloren, abgelaufenes Produkt, Unterkochen)

Schritte:
1. Sub-Rezept-Zeile im aufgeklappten Bereich identifizieren
2. **"+ Add WO"** klicken beim Hovern auf Zieldatum/Schicht
3. Formular ausfüllen:
   - Zielmenge (Anzahl Portionen)
   - Geplantes Datum/Schicht
   - **Erstellungsgrund** (Pflichtfeld!)
   - Kochmethoden

---

## 7. BULK-OPERATIONEN (MASSENBEARBEITUNG)

### Bulk-Edit-Modus aktivieren
1. **"Bulk Edit"**-Button im Kalender-Header klicken
2. Checkboxen erscheinen auf allen AA-Chips
3. Rezept-Zeilen aufklappen → Sub-Rezept-AAs auswählen
4. **Bulk Edit Ribbon** erscheint unten mit Anzahl ausgewählter AAs

### Bulk Edit Ribbon – Optionen
- **"Aufträge bearbeiten":** Öffnet Seitenpanel für Gruppen- oder Einzelbearbeitung
- **"Aufträge sperren":** Alle ausgewählten AAs gleichzeitig sperren
- **"Aufträge entsperren":** Alle ausgewählten AAs gleichzeitig entsperren
- **"Aufträge stornieren":** Mehrere AAs mit Pflichtkommentar stornieren

### Bulk Edit Workflow
1. Bulk-Edit-Modus aktivieren → AAs auswählen
2. Filter nutzen zum Eingrenzen, dann "Alle auswählen" oder manuell wählen
3. "Aufträge bearbeiten" → Zweispaltiges Seitenpanel öffnet sich
4. Rezept- und Sub-Rezept-AAs nebeneinander anzeigen
5. Globale Änderungen oder individuelle Anpassungen vornehmen
6. "Speichern" oder "Speichern & Sperren"
7. Kalender re-validiert Constraints → neue Warnungen werden angezeigt

---

## 8. DRAG & DROP

- **Ungesperrte AAs** per Drag & Drop umplanen
- AA-Chip halten, an neue Schicht ziehen → loslassen
- **Grüne Markierung** = Gültiger Drop-Platz
- **Rote Markierung** = Ungültig (würde Constraint-Verletzung erzeugen)
- Gesperrte AAs: Verschieben erfordert Bestätigung

---

## 9. GERÄTEKAPAZITÄTS-PLANUNG

### Equipment Drawer öffnen
- **Equipment-Toggle** im Kalender-Header aktivieren

### Equipment Drawer – Layout
- Jede konfigurierte Geräte-Art erscheint als separate Zeile
- Kapazitätsauslastung für jede Datum/Schicht-Kombination:
  - **Weiß/Normal:** Normale Auslastung
  - **Orange (> 80%):** Nähert sich Kapazitätsgrenze
  - **Rot (≥ 100%):** Kapazität überschritten!
- Filter: Alle AAs / Nur gesperrte / Nur ungesperrte

### Echtzeit-Feedback beim Erstellen von Sub-Rezept-AAs
- **Aktuelle Kapazität:** Zeigt bestehende Auslastung vor dem neuen AA
- **Projizierte Kapazität:** Aktualisiert sich live beim Ändern von Zielmengen und Kochmethoden
- **Cook-Method-Overrides:** Aktivieren sich, wenn alternative Kochmethoden konfiguriert sind

---

## 10. ARBEITSAUFTRÄGE SPERREN

### Warum sperren?
- Gesperrte AAs werden an nachgelagerte Systeme übertragen: **Execution Tracker, WMS, IMT**
- Gesperrte AAs erscheinen im **RTEM Live Work Orders Google Sheet**
- WMS beginnt mit der Ausführungsplanung

### Einzelne AAs sperren
1. AA-Chip klicken → Bearbeitungs-Popover öffnet sich
2. **"Speichern & Sperren"** Button nutzen

### Bulk-Sperren
1. Bulk-Edit-Modus aktivieren
2. Mehrere AAs auswählen
3. **"Aufträge sperren"** im Bulk Edit Ribbon klicken

### Nach dem Sperren
- Gesperrte AAs können trotzdem bearbeitet werden
- Je nach WMS-Status können Einschränkungen gelten

---

## 11. ÜBERWACHUNG & AUSFÜHRUNG

### Statusfortschritt – Rezept-AAs
1. **Grau – Geplant gesperrt:** Gesperrt für Produktion
2. **Grün mit Cloche-Icon – Platierung läuft:** Aktive Platierung (in den letzten 30 Minuten)
3. **Grün mit Häkchen – Platierung abgeschlossen:** Zielportionen erreicht oder überschritten

### Statusfortschritt – Sub-Rezept-AAs
1. **Grau – Geplant gesperrt:** Gesperrt für Produktion
2. **Grau – Bereit, nicht gestartet:** Entsperrt, aber WMS noch nicht begonnen
3. **Grau mit Tortendiagramm – In Arbeit:** WMS-Ausführungsphasen:
   - Picking → Staged → Debox → Kitchen In-Process → Pre Blast → Post Blast → Holding Cooler
4. **Grün mit Häkchen – Koch abgeschlossen:** Portionen erreicht oder überschritten

### WMS-Einschränkungen (wann kann ich nicht mehr bearbeiten?)
| WMS-Status | Was kann noch bearbeitet werden |
|---|---|
| Vor Picking | Alle Felder editierbar |
| Nach Picking-Start | Nur Tag/Schicht und Kochmethode, NICHT die Zielmenge |
| Nach Kitchen In-Process | Keine Bearbeitung oder Stornierung mehr möglich |

### Was tun wenn AA nicht mehr bearbeitbar ist?
- Im Bearbeitungs-Popover des gesperrten AAs: **"Add Another WO"** Button
- Erstellt neuen AA in der gleichen Datum/Schicht-Zelle

### Häufige Eingriffs-Szenarien
- **Produktionsprobleme:** Neue Sub-Rezept-AAs für Blast-Verlust, abgelaufenes Produkt, Unterkochen
- **Prognoseänderungen:** Rezept- und Sub-Rezept-AAs hinzufügen für erhöhten Bedarf

---

## 12. SCHNELL-REFERENZ

### Planungs-Timeline

| Zeitpunkt | Was passiert | Was tun |
|---|---|---|
| Woche -3 | Initiale Planung beginnt | Rezept-AAs erstellen, Sub-Rezept-AAs auto-generieren, Gerätekapazität prüfen |
| Woche -2 | Mid-Planning, Min Needs können erscheinen | Constraint-Warnungen prüfen und beheben |
| Woche -1 | Min Needs ersetzen OSCAR, Plan finalisieren | Ungesperrte AAs anpassen, Bulk-Sperren durchführen |
| Produktionswoche | Ausführung überwachen | Chip-Status beobachten, neue AAs bei Problemen erstellen |

### Rezept vs. Sub-Rezept-AAs

| Typ | Wofür | Wann erstellen |
|---|---|---|
| **Rezept-AA** | Platierläufe, Wochenziele setzen | Vorläufige Planung (Woche -3) |
| **Sub-Rezept-AA** | Kochvorgänge, Komponentenherstellung | Auto mit Rezept-AA oder manuell |

### Einzeln vs. Bulk-Operationen

| Einzeln | Bulk |
|---|---|
| Erste Planung | Sperren/Entsperren vieler AAs |
| Spezifische Anpassungen | Globale Zieländerungen |
| Constraint-Auflösung | Effiziente Massenverwaltung |

### Auto-Generierung vs. Manuelle Erstellung

| Auto | Manuell |
|---|---|
| Standard in Vorabplanung | Constraint-Verletzungen auflösen |
| Neue vollständige Läufe | Ausführungsreaktionen (Blast verloren, etc.) |

---

## 13. TYPISCHE PLANUNGSWORKFLOWS

### Workflow A: Vorläufige Planung (Woche -3)
1. MPT öffnen → DC und Menüwoche auswählen
2. Erste Rezept-Zeile identifizieren
3. "+ Add Plan" in Zieldatum/Schicht klicken
4. Zielmenge (%) eingeben, Erstellungsgrund "Planned" wählen
5. ✅ "Sub-Rezept-AAs erstellen" aktivieren
6. Sub-Rezept-Werte prüfen und ggf. anpassen
7. **"Ungesperrt speichern"** (empfohlen für automatische Anpassungen)
8. Equipment-Drawer öffnen → Kapazität prüfen
9. Orange Warnungen auflösen
10. Schritte für alle weiteren Rezepte wiederholen

### Workflow B: Constraint-Auflösung
1. **Oranges Warnsymbol** im Header klicken
2. Alle Probleme anzeigen lassen (nach Rezept/Sub-Rezept/Plan sortiert)
3. Problem-AA-Chip klicken → Popover öffnen
4. Je nach Constraint-Typ:
   - **Min Needs Fehler:** Rezept-AA hinzufügen oder Zielmenge erhöhen
   - **Geräte-Fehler:** AA in andere Schicht verschieben oder Cook-Method-Override wählen
   - **Haltbarkeits-Fehler:** Kochtermin näher an Platierung verschieben
5. Speichern → System re-validiert
6. Prüfen ob Problem behoben

### Workflow C: Endplanung & Sperren (Woche -1)
1. Min Needs Chips prüfen – sind alle Tagesziele erfüllt?
2. Ungesperrte AAs anpassen bei Prognoseänderungen
3. Alle Constraints auflösen
4. **Bulk Edit** aktivieren → Alle AAs auswählen
5. **"Aufträge sperren"** → Bestätigen
6. Im RTEM Live Work Orders Sheet prüfen: AAs erschienen?

### Workflow D: Ausführungs-Monitoring (Produktionswoche)
1. Kalender mit aktueller Woche öffnen
2. Chip-Farben beobachten:
   - Grün → OK, in Arbeit oder fertig
   - Orange/Rot → Problem! Sofort handeln
3. Bei Produktionsproblem (Blast verloren usw.):
   - Betroffenes Sub-Rezept-AA klicken
   - Falls WMS gesperrt → "Add Another WO" nutzen
   - Neuen AA mit Erstellungsgrund "Execution Response" erstellen
4. Bei Forecast-Änderung:
   - Rezept-AA anpassen (falls ungesperrt)
   - Falls gesperrt: neuen Rezept-AA hinzufügen

---

## 14. GLOSSAR

| Begriff | Deutsch | Bedeutung |
|---|---|---|
| MPT | Produktionsplanungs-Tool | Manufacturing Planning Tool |
| Recipe WO | Rezept-Arbeitsauftrag | Repräsentiert einen Platierlauf |
| Sub-Recipe WO | Sub-Rezept-Arbeitsauftrag | Repräsentiert einen Kochvorgang |
| Min Needs | Mindestbedarf | Tägliche Mindestmengen für Kundenzustellung |
| OSCAR | OSCAR-Prognose | Wöchentliche Mengenprognose (>1 Woche voraus) |
| Constraint | Planungsbeschränkung | Validierungsregel im MPT |
| Lock/Sperren | Sperren | AA wird an Downstream-Systeme übertragen |
| Chip | Chip | Visuelles Element im Kalender = ein Arbeitsauftrag |
| DC | Verteilzentrum | Distribution Center (z.B. Verden) |
| WMS | Lagerverwaltungssystem | Warehouse Management System |
| IMT | IMT | Inventory Management Tool |
| MSKU | MSKU | Produkt-Stammdaten-Tool |
| Blast | Schockkühlung | Schnelles Abkühlen nach dem Kochen |
| Plating | Platieren | Finale Rezept-Zusammenstellung |
| Cook Method Override | Kochmethoden-Ersatz | Alternative Kochmethode wenn Standard nicht verfügbar |
| Bulk Edit | Massenbearbeitung | Gleichzeitige Bearbeitung vieler AAs |
| PPT | PPT | Production Planning Tool (Menüzusammenstellung) |
