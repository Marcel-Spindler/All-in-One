# Factor Weekly Fulfillment GSheet

## Quelle

- Titel: OUTPUT - [F_ x HF] Weekly Fulfillment Report
- Spreadsheet ID: 1YscgiuKYVI2pGcMJ3RcJwWGQEkG46RnVnji8q8a4AeE
- Zweck: zentrale Factor-/HF-Wochensteuerung mit Output-, KPI-, Produktions-, Staffing-, Logistik-, Forecast- und Issue-Daten
- Hinweis: Das Sheet wird laufend neu befuellt. Integrationen duerfen deshalb nie auf festen Zeilennummern beruhen, sondern auf Tab-Namen, Kopfzeilen und KW-Werten.

## Tab-Landkarte

### Overview

- beschreibt die Gesamtarchitektur des Reportings
- trennt in Input sheet, Output sheet und Management sheet
- macht klar, welche Tabs fuer Produktion/PS relevant sind

### Operations Agenda

- Weekly Operations Dashboard fuer die aktuelle Kalenderwoche
- enthaelt KPI-Block mit z.B. Performance MPB, Boxes, Hours, Lines, Worker
- enthaelt Last-Week-Review nach Departments mit Status und Kommentaren
- gut geeignet fuer ein Weekly Briefing im Tool

### Staffing

- Staffing-/Stationsmatrix fuer DE
- zeigt Personal- und Stationslogik fuer Box rack, Liner, Packaging, Chilled Area und Pick-/Runner-Rollen
- eher Layout-/Kapazitaetsmatrix als saubere Tabellenliste
- wichtig fuer spaetere Personal- oder Linienplanung, aber nicht als erste API-Quelle fuer Summenwerte

### Produktionsvorbereitung_DE

- wichtigster operativer Factor-DE-Tab
- Beispiel-KW: 2026-W15
- Kopfbereich enthaelt Box Volumen, Meal Volumen, Hours Fr, Hours Su
- Detailtabelle enthaelt u.a.:
  - Woche
  - Rezept
  - Maitre Code
  - SKU
  - Friday
  - Sunday
  - Summe Soll
  - Paletten Friday
  - Paletten Sunday
  - Anzahl an Meals
  - Fulfillment + Convini
  - Bestand (Inbounded)
  - Blocked by QC + QA
  - zu viel/zu wenig
  - Reparieren Sleeves
  - speed
  - Startzeit / Endzeit / Max Kapa pro Tag als Kontextspalten im rechten Bereich
- das ist die beste Quelle fuer den operativen Factor-Wochenplan auf Rezept-/SKU-Ebene

### Produktionsvorbereitung_Nordics

- gleiche Grundidee wie DE, aber fuer Nordics
- fuer den aktuellen PS-Copilot nur zweite Prioritaet, solange der Fokus auf Factor DE liegt

### Planung - PDL_ databrick

- strukturierte Box-/PDL-Quelle
- sehr wertvoll fuer den Produktionsplaner
- Kopfzeilen:
  - hellofresh_week
  - boxid
  - delivery_date
  - production_date
  - weekday_production_date
  - distribution_center
  - meal_swap
  - extras
  - lane_by_delivery_time
  - total_ice_count
  - box_size
  - cool_pouch_name
- Beispiel: KW 2026-W15, production_date 2026-04-03, distribution_center VE
- meal_swap enthaelt direkt die Rezeptmischung pro Box, z.B. 301:1 302:1 303:1 ...
- cool_pouch_name ist JSON-artig und enthaelt den Liner pro Boxgroesse
- diese Tabelle ist die wichtigste dynamische Rohdatenquelle fuer Factor im Tool

### PCK Vorbereitung Logistik

- PCK-/Verpackungslogistik fuer DE und Nordics
- Spalten u.a.:
  - Woche
  - SKU
  - Artikel
  - Friday
  - Sunday bzw. TK/TV
  - Summe
  - Menge pro Palette
  - Anbruchpalette
  - PCK Menge ohne Anbruchpalette
  - Paletten pro Stunde
- gut fuer Verpackungsmaterial, Liner und Palettenbedarf

### QC/QA - FSQC

- Sperrungen, OOS, Packaging-Fehler, MHD, Kennzeichnungsfehler
- Spalten u.a.:
  - Lieferdatum
  - Bezeichnung
  - Factor SKU
  - Anzahl gesperrt
  - Sperrort
  - Sperrgrund
  - Kommentar
  - Bilder Link
- wichtig fuer Risikokontext im Wochenbriefing und fuer Abweichungswarnungen je Rezept/SKU

### Maitre Forecast DE

- Forecast-Historie und kurzfristige Tages-/Wochenprognose
- Spalten u.a.:
  - Market
  - week
  - Recipe Slot Number
  - SKU Code
  - Recipe Code
  - Maitre Code
  - wed -4wk bis Thurs
  - order
- gut fuer Forecast vs Plan und Volumenverschiebungen

### Produktionsdaten

- historische Ist-Daten fuer Produktion, Logistik und Quality
- Spalten u.a.:
  - KW
  - Datum
  - Tag
  - Team
  - Number of workers VA/NVA
  - Runtime [h]
  - Produced Boxes [Boxes]
  - Linespeed Grafana [Boxes/h]
  - Produced Meals [Meals]
  - Meals/Box
  - Inbounded pallets / Outbounded pallets
  - Leftovers [Meals]
  - Checked Pallets [Pallets]
  - Error in Labeling [Errors]
- gut fuer retrospektive Performance- und Line-Speed-Modelle

### Issue Tracker

- operative Probleme, Ursachen, Auswirkungen, Box IDs, Statuslogik
- geeignet fuer Eskalationen, Substitutions-Historie und Incident-Kontext
- gute Quelle fuer Problem-Summary im Tagesbriefing

## Was fuer Factor im Tool direkt nutzbar ist

### Sofort nutzbar

- Planung - PDL_ databrick: Boxen, Meal-Swaps, Boxgroessen, Liner, Distribution Center, Produktionstag
- Produktionsvorbereitung_DE: Rezept-/SKU-Volumen, Bestand, QC-Blocker, Paletten, Delta zu inbounded stock
- PCK Vorbereitung Logistik: Verpackungs- und Palettenbedarf
- Operations Agenda: Wochen-KPIs und Kommentar-Blöcke

### Sehr sinnvoll als Kontextlayer

- QC/QA - FSQC: Sperrungen und Qualitaetsblocker
- Issue Tracker: Problemhistorie und Substitutions-/Lieferabweichungen
- Produktionsdaten: echte historische Leistung, Linespeed und Teamgroessen
- Maitre Forecast DE: Forecast gegen Wochenplan

## Integrationsregeln

- Immer KW aus dem Sheet lesen, nie hart im Code verdrahten
- Kopfzeilen suchen statt feste Spaltenpositionen vorauszusetzen
- Leere oder verschobene Layout-Zeilen in visuellen Tabs tolerieren
- Produktionsvorbereitung_DE ist halb Layout, halb Datentabelle: dort ab der Zeile mit "Woche | Rezept | Maitre Code | SKU" arbeiten
- Planung - PDL_ databrick ist die stabilste strukturierte Tabelle fuer Factor-Boxdaten
- QC/QA und Issue Tracker als additive Kontextquellen behandeln, nicht als Pflichtquelle fuer den Grundplan

## Empfohlene naechste Verwendung im PS Copilot

1. Factor-Wochenbriefing direkt aus Operations Agenda + Produktionsvorbereitung_DE + PDL_ databrick bauen
2. Delta-Check auf Rezeptbasis aus Produktionsvorbereitung_DE ableiten: Summe Soll vs Bestand vs QC-Blocker vs zu viel/zu wenig
3. PCK Vorbereitung Logistik neben den Produktionsplaner setzen fuer Box-/Liner-/Palettenbedarf
4. QC/Issue-Overlay je Rezept oder KW bauen
5. Maitre Forecast DE spaeter fuer Prognose-Ansicht gegen aktuelle KW verwenden
